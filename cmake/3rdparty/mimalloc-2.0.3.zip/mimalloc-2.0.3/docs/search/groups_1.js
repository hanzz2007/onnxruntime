var searchData=
[
  ['basic_20allocation',['Basic Allocation',['../group__malloc.html',1,'']]]
];
