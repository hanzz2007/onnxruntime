var searchData=
[
  ['overriding_20malloc',['Overriding Malloc',['../overrides.html',1,'']]]
];
